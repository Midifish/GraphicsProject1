NOTE: 
Loading textures remotely in Chrome is difficult Three.js, therefore I have opted to use 
a website shortcut to my github-hosted project to ensure Chrome support. I have approval from Dr. Watson to do this
instead of using index.html. You should navigate to midifish.github.io in Chrome to see my program or
just double click the "ChromeFriendlyVersion" shortcut included. You may verify my code at
https://github.com/midifish/midifish.github.io . Alternatively, you may open index.html in Firefox, and it will work just fine.

Extra Credit:
-Track and Display Score (+2%)
-Levels (+3%)
-First Person Frogger (+3%)
-Additional Vehicle or Creature (+4%)
-Sound and music (+5%)

Screencast Demo Link:
https://www.youtube.com/watch?v=tZDuRLem3VE&feature=youtu.be